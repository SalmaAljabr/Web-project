<?php
session_start(); // Start session to store user information.

$error_message = ''; // Initialize an empty error message.

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    $username = $_POST['username'] ?? ''; // Get the username or set it to an empty string.
    $password = $_POST['password'] ?? ''; // Get the password or set it to an empty string.

    // Database connection details
    $dsn = 'mysql:host=localhost;dbname=coding_challenges';
    $db_user = 'root'; 
    $db_pass = '';  //Your password   

    try {
        // Create a database connection
        $pdo = new PDO($dsn, $db_user, $db_pass);
    } catch (PDOException $e) {
        die("Database connection failed."); // Exit with a generic error if connection fails.
    }

    // Check if username exists in the database
    $sql = "SELECT password FROM users WHERE username = ?"; // Check the names if mataches your database
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // If login is successful, store the username in session and redirect.
        $_SESSION['username'] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        // If login fails, set an error message.
        $error_message = "Invalid username or password.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Coding Challenges</title>
    <link rel="stylesheet" href="project.css"> 
</head>

<body class="login-page">
    <div class="SignupLogin-container">
        <h1>Welcome Back!</h1>
        <p>Please enter your details to continue.</p>
        <!-- The form sends data to login.php via POST method -->
        <form id="login-form" action="login.php" method="POST">
            <input type="text" name="username" id="username" placeholder="Username" required>
            <input type="password" name="password" id="password" placeholder="Password" required>
            <button type="submit" id="login-form-submit">Login</button>
            <!-- Display error message dynamically if it exists in the URL -->
            <?php if (!empty($_GET['error_message'])): ?>
                <p id="login-error-msg" style="color: red;">
                    <!-- Display the error message safely using htmlspecialchars -->
                    <?= htmlspecialchars($_GET['error_message']) ?>
                </p>
            <?php endif; ?>
        </form>
        <p class="footer-text">
            Don't have an account? <a href="SignUpPage.html">Sign Up</a>
        </p>
    </div>
</body>
</html>


