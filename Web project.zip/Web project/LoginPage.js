// Get the login form element by its ID
const loginForm = document.getElementById("login-form");

// Get the login button element by its ID
const loginButton = document.getElementById("login-form-submit");

// Get the login error message element by its ID
const loginErrorMsg = document.getElementById("login-error-msg");

loginButton.addEventListener("click", (e) => {
    // Prevent the form from submitting and refreshing the page
    e.preventDefault();
    
    const username = loginForm.username.value;
    const password = loginForm.password.value;

    // Check if the username and password match the correct credentials
    if (username === "sql" && password === "sql") {
        // Display a success message to the user
        alert("You have successfully logged in.");
        
        // Reload the page (for example, to redirect or reset the form)
        location.reload();
    } else {
        // If credentials are incorrect, display the error message by setting opacity to 1
        loginErrorMsg.style.opacity = 1;
    }
});
