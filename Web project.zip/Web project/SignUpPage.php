<?php
// Start a session for feedback messages
session_start();

// Initialize an error message variable
$error_message = '';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user inputs
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Basic validation
    if (strlen($username) < 5) {
        $error_message = "Username must be at least 5 characters.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email address.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } else {
        // Database connection
        $conn = new mysqli("localhost", "root", "", "");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = "Username or email already exists.";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed_password);

            if ($stmt->execute()) {
                // Success: Redirect to login page
                $_SESSION['success_message'] = "Account created successfully! Please log in.";
                header("Location: login.php");
                exit();
            } else {
                $error_message = "Error occurred. Please try again.";
            }
        }

        // Close the connection
        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Coding Challenges</title>
    <link rel="stylesheet" href="project.css">
</head>
<body class="signup-page">
    <div class="SignupLogin-container">
        <h1>Create Account</h1>
        <p>Sign up to get started!</p>
        <!-- Form sends data to signup.php -->
        <form action="signup.php" method="POST">
            <input type="text" name="username" placeholder="Username (min 5 characters)" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password (min 8 characters)" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Sign Up</button>
            <!-- Display error message if any -->
            <?php if (!empty($error_message)): ?>
                <p style="color: red;"><?= htmlspecialchars($error_message) ?></p>
            <?php endif; ?>
        </form>
        <p class="footer-text">
            Already have an account? <a href="login.php">Log in</a>
        </p>
    </div>
</body>
</html>
