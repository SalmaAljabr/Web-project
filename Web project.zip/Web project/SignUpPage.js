// JavaScript for handling the signup process

// Selecting form elements and error message by their IDs
const signupForm = document.getElementById("signup-form");               
const signupButton = document.getElementById("signup-form-submit");      
const signupErrorMsg = document.getElementById("signup-error-msg");     


signupButton.addEventListener("click", (e) => {
    // Prevent the form from submitting and refreshing the page by default
    e.preventDefault();

    // Get the values entered by the user in the form fields
    const username = document.getElementById("username").value;          
    const email = document.getElementById("email").value;              
    const password = document.getElementById("password").value;        
    const confirmPassword = document.getElementById("confirm-password").value; 

    // Check if the password and confirm password fields match
    if (password !== confirmPassword) {
        signupErrorMsg.style.opacity = 1;  // Make the error message visible
    } else {
        signupErrorMsg.style.opacity = 0;  // Hide the error message
        alert("Account created successfully!"); 

        // Redirect the user to the login page or another relevant page (uncomment if needed)
        // window.location.href = "LoginPage.html"; // Redirect to the login page
    }
});
